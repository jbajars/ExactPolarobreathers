%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Define simulation variables (u,a,p,b) in structure <vars>
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Variables
vars.u = zeros(parm.N,1);
vars.a = zeros(parm.N,1);
vars.p = zeros(parm.N,1);
vars.b = zeros(parm.N,1);
